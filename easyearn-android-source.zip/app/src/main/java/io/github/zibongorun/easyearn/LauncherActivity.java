package io.github.zibongorun.easyearn;
import android.app.*;import android.os.*;import android.content.*;import android.graphics.Color;import android.net.Uri;import android.webkit.*;import android.widget.*;import com.google.firebase.auth.*;import com.google.android.gms.tasks.Tasks;import java.net.*;import java.io.*;import java.util.concurrent.*;import org.json.*;
public class LauncherActivity extends Activity {
 private WebView web;private ValueCallback<Uri[]> fileCallback; private final ExecutorService io=Executors.newSingleThreadExecutor();
 private final String home="https://zibongorun.github.io/my-project/easyearn-usar/easyearn.html?nativePush=1";
 @Override public void onCreate(Bundle state){super.onCreate(state);
  getWindow().setStatusBarColor(Color.rgb(8,20,36));getWindow().setNavigationBarColor(Color.rgb(8,20,36));
  androidx.core.view.WindowCompat.setDecorFitsSystemWindows(getWindow(),false);
  androidx.core.view.WindowInsetsControllerCompat bars=new androidx.core.view.WindowInsetsControllerCompat(getWindow(),getWindow().getDecorView());bars.setAppearanceLightStatusBars(false);bars.setAppearanceLightNavigationBars(false);
  FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(8,20,36));setContentView(root);
  androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root,(v,insets)->{androidx.core.graphics.Insets b=insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars()|androidx.core.view.WindowInsetsCompat.Type.displayCutout());v.setPadding(b.left,b.top,b.right,b.bottom);return insets;});
  androidx.core.view.ViewCompat.requestApplyInsets(root);
  web=new WebView(this);root.addView(web,new FrameLayout.LayoutParams(-1,-1));
  web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);web.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
  web.addJavascriptInterface(new Bridge(),"EasyEarnNative");web.getSettings().setSupportMultipleWindows(true);
  web.setWebChromeClient(new WebChromeClient(){
   @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){if(fileCallback!=null)fileCallback.onReceiveValue(null);fileCallback=callback;try{startActivityForResult(params.createIntent(),42);return true;}catch(Exception e){fileCallback=null;return false;}}
   @Override public boolean onCreateWindow(WebView v,boolean dialog,boolean gesture,android.os.Message result){if(!gesture)return false;WebView child=new WebView(LauncherActivity.this);child.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){try{startActivity(new Intent(Intent.ACTION_VIEW,r.getUrl()));}catch(Exception ignored){}v.destroy();return true;}});((WebView.WebViewTransport)result.obj).setWebView(child);result.sendToTarget();return true;}
  });
  if(Build.VERSION.SDK_INT>=33)getOnBackInvokedDispatcher().registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT,()->onBackPressed());
  web.setWebViewClient(new WebViewClient(){@Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){Uri u=r.getUrl();if("https".equals(u.getScheme())&&"zibongorun.github.io".equals(u.getHost())&&u.getPath().startsWith("/my-project/easyearn-usar/"))return false;try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;}});
  ImageView splash=new ImageView(this);splash.setImageResource(R.drawable.easyearn_logo);splash.setBackgroundColor(Color.WHITE);splash.setScaleType(ImageView.ScaleType.FIT_CENTER);root.addView(splash,new FrameLayout.LayoutParams(-1,-1));
  if(state==null)web.loadUrl(notificationUrl(getIntent()));else web.restoreState(state);
  new Handler(Looper.getMainLooper()).postDelayed(()->root.removeView(splash),2200);
 }
 private String notificationUrl(Intent intent){return home+("history".equals(intent.getStringExtra("route"))?"&history=1":intent.hasExtra("noticeId")?"&notice=1":"");}
 @Override protected void onNewIntent(Intent intent){super.onNewIntent(intent);setIntent(intent);if(intent.hasExtra("noticeId"))web.loadUrl(notificationUrl(intent));}
 private class Bridge {@JavascriptInterface public String appInfo(){try{android.content.pm.PackageInfo p=getPackageManager().getPackageInfo(getPackageName(),0);JSONObject n=new JSONObject();n.put("versionCode",androidx.core.content.pm.PackageInfoCompat.getLongVersionCode(p));n.put("versionName",p.versionName);return n.toString();}catch(Exception e){return "null";}}@JavascriptInterface public void request(String id,String path,String body){
  if(!path.equals("/link")&&!path.equals("/inbox")&&!path.equals("/unlink")&&!path.equals("/history"))return;
  io.execute(()->{String result;try{FirebaseAuth a=FirebaseAuth.getInstance();if(a.getCurrentUser()==null)Tasks.await(a.signInAnonymously(),30,TimeUnit.SECONDS);String t=Tasks.await(a.getCurrentUser().getIdToken(false),30,TimeUnit.SECONDS).getToken();
   HttpURLConnection c=(HttpURLConnection)new URL("https://easyearn-push.mdrkibhossain7.workers.dev"+path).openConnection();c.setConnectTimeout(15000);c.setReadTimeout(15000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json");c.setRequestProperty("Origin","https://zibongorun.github.io");c.setRequestProperty("Authorization","Bearer "+t);try(OutputStream o=c.getOutputStream()){o.write(body.getBytes("UTF-8"));}InputStream in=c.getResponseCode()<400?c.getInputStream():c.getErrorStream();ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1)out.write(b,0,n);result=out.toString("UTF-8");c.disconnect();
  }catch(Exception e){result="{\"ok\":false,\"error\":\"সংযোগ হয়নি\"}";}final String value=result;runOnUiThread(()->{if(!isFinishing())web.evaluateJavascript("window.eeNativeReply&&window.eeNativeReply("+JSONObject.quote(id)+","+JSONObject.quote(value)+")",null);});});
 }}
 @Override protected void onActivityResult(int code,int result,Intent data){super.onActivityResult(code,result,data);if(code==42&&fileCallback!=null){fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result,data));fileCallback=null;}}
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override public void onSaveInstanceState(Bundle b){web.saveState(b);super.onSaveInstanceState(b);}
 @Override public void onDestroy(){io.shutdownNow();web.removeJavascriptInterface("EasyEarnNative");web.destroy();super.onDestroy();}
}
