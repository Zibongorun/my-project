package io.github.zibongorun.easyearn;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.*;
public class EasyEarnMessagingService extends FirebaseMessagingService {
 @Override public void onNewToken(String token){PushSetup.register(this);}
 @Override public void onMessageReceived(RemoteMessage message){
  PushSetup.channel(this);
  if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
  String title=message.getData().get("title"),body=message.getData().get("body"),notice=message.getData().get("noticeId");
  if(message.getNotification()!=null){title=message.getNotification().getTitle();body=message.getNotification().getBody();}
  Intent i=new Intent(this,LauncherActivity.class).putExtra("noticeId",notice).putExtra("route",message.getData().get("route")).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
  int id=notice==null?100:notice.hashCode();
  PendingIntent tap=PendingIntent.getActivity(this,id,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification n=new NotificationCompat.Builder(this,PushSetup.CHANNEL).setSmallIcon(R.drawable.ic_notification_icon).setColor(android.graphics.Color.rgb(16,74,186)).setContentTitle(title==null?"EasyEarn":title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setPriority(NotificationCompat.PRIORITY_HIGH).setDefaults(Notification.DEFAULT_ALL).setAutoCancel(true).setContentIntent(tap).build();
  ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(id,n);
 }
}
