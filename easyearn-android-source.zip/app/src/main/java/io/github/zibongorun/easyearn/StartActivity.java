package io.github.zibongorun.easyearn;
import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
public class StartActivity extends Activity {
 private static final int PERMISSION=20;
 @Override public void onCreate(Bundle b){super.onCreate(b);PushSetup.channel(this);
  if(Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED||getSharedPreferences("push",0).getBoolean("asked",false)){open();return;}
  getWindow().getDecorView().setBackgroundColor(Color.rgb(8,20,36));
  if(b==null)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},PERMISSION);
 }
 @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==PERMISSION){getSharedPreferences("push",0).edit().putBoolean("asked",true).apply();open();}}
 private void open(){
  try{PushSetup.register(this);}catch(Exception e){android.util.Log.e("EasyEarn","Push registration setup failed",e);}
  try{
   Intent i=new Intent(this,LauncherActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
   if(getIntent().getExtras()!=null)i.putExtras(getIntent().getExtras());
   startActivity(i);finish();
  }catch(Exception e){
   new AlertDialog.Builder(this).setTitle("EasyEarn খুলতে সমস্যা").setMessage(e.getClass().getSimpleName()+": "+e.getMessage()).setPositiveButton("আবার চেষ্টা করুন",(d,w)->open()).show();
  }
 }
}
