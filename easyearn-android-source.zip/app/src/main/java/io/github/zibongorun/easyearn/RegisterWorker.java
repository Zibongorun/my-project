package io.github.zibongorun.easyearn;
import android.content.Context;
import androidx.annotation.NonNull;
import androidx.work.*;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.auth.*;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import java.net.*;
import java.io.*;
import java.util.concurrent.TimeUnit;
public class RegisterWorker extends Worker {
 public RegisterWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull @Override public Result doWork(){
  HttpURLConnection connection=null;
  try{
   FirebaseAuth auth=FirebaseAuth.getInstance();
   if(auth.getCurrentUser()==null)Tasks.await(auth.signInAnonymously(),30,TimeUnit.SECONDS);
   String id=Tasks.await(auth.getCurrentUser().getIdToken(false),30,TimeUnit.SECONDS).getToken();
   String token=Tasks.await(FirebaseMessaging.getInstance().getToken(),30,TimeUnit.SECONDS);
   connection=(HttpURLConnection)new URL("https://easyearn-push.mdrkibhossain7.workers.dev/register").openConnection();
   connection.setRequestMethod("POST");connection.setConnectTimeout(15000);connection.setReadTimeout(15000);connection.setDoOutput(true);
   connection.setRequestProperty("Content-Type","application/json");connection.setRequestProperty("Authorization","Bearer "+id);
   connection.setRequestProperty("Origin","https://zibongorun.github.io");
   byte[] data=new JSONObject().put("token",token).put("platform","android").toString().getBytes("UTF-8");
   try(OutputStream out=connection.getOutputStream()){out.write(data);}
   int code=connection.getResponseCode();
   if(code>=200&&code<300){getApplicationContext().getSharedPreferences("push",0).edit().putBoolean("registered",true).apply();return Result.success();}
   return Result.retry();
  }catch(Exception e){return Result.retry();}finally{if(connection!=null)connection.disconnect();}
 }
}
