package io.github.zibongorun.easyearn;
import android.app.*;
import android.content.*;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Build;
import androidx.work.*;
import java.util.concurrent.TimeUnit;
public final class PushSetup {
 public static final String CHANNEL="easyearn_notices_v1";
 public static void channel(Context c){
  if(Build.VERSION.SDK_INT>=26){
   NotificationChannel n=new NotificationChannel(CHANNEL,"EasyEarn নোটিশ",NotificationManager.IMPORTANCE_HIGH);
   n.setDescription("অ্যাডমিনের নতুন নোটিশ");n.enableVibration(true);
   n.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION),new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).build());
   c.getSystemService(NotificationManager.class).createNotificationChannel(n);
  }
 }
 public static void register(Context c){
  Constraints network=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();
  WorkManager w=WorkManager.getInstance(c);
  w.enqueueUniqueWork("easyearn-register",ExistingWorkPolicy.REPLACE,new OneTimeWorkRequest.Builder(RegisterWorker.class).setConstraints(network).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,30,TimeUnit.SECONDS).build());
  w.enqueueUniquePeriodicWork("easyearn-renew",ExistingPeriodicWorkPolicy.KEEP,new PeriodicWorkRequest.Builder(RegisterWorker.class,7,TimeUnit.DAYS).setConstraints(network).build());
 }
}
